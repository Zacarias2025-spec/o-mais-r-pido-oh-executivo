import Products from "@/components/Products";
import CompanyInfo from "@/components/CompanyInfo";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Phone } from "lucide-react";
import { useNavigate } from "react-router-dom";

const ProductsPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-8">
          <Button
            onClick={() => navigate("/")}
            variant="outline"
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Button>
          
          <a 
            href="tel:924829157" 
            className="flex items-center gap-2 text-lg font-semibold text-primary hover:text-primary/80 transition-colors"
          >
            <Phone className="w-5 h-5" />
            924 829 157
          </a>
        </div>
      </div>
      
      <Products />
      <CompanyInfo />
    </div>
  );
};

export default ProductsPage;
